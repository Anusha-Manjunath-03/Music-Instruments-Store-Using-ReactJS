import logo from './logo.svg';
import './App.css';
import Header from './components/front/Header/Header';
import { data } from './components/back/data';
import MyRoutes from './components/front/Routes/Routes';
import { useState } from 'react';
import Footer from './components/front/Footer/Footer';

function App() {

  const {musicInst} = data;
  const [cartItems,setCartItems] = useState([]);

  const handleAddInst = (instrument)=>{
    const instExist = cartItems.find((inst)=>
      instrument.id === inst.id
    );

    if(instExist){
      setCartItems(
        cartItems.map(
          (inst) =>
          inst.id === instrument.id ? {...instExist,q:inst.q+1}:inst
        )
      )
    }
    else{
      setCartItems(
        [...cartItems,{...instrument, q:1}]
      )
    }
  }

  const handleRemoveInst = (instrument)=>{
    const instExist = cartItems.find((inst)=>
      instrument.id === inst.id
    );
    if(instExist.q === 1){
      setCartItems(
        cartItems.filter(
          (inst) => inst.id !== instrument.id
        )
      )
    }
    else{
      setCartItems(
        cartItems.map(
          (inst)=>inst.id === instrument.id ? {...instExist,q:instExist.q-1}:inst
        )
      )
    }
  }
  
  const handleClearCart = ()=>{
    alert('Clearing Cart...');
    setCartItems([]);
  }

  return (
    <div className="App">
      <Header />
      <MyRoutes musicInst = {musicInst} handleAddInst={handleAddInst} handleRemoveInst={handleRemoveInst} handleClearCart={handleClearCart} cartItems={cartItems}/>
      <Footer />
    </div>
  );
}

export default App;
