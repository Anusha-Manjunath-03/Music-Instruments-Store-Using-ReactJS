export const data = {
    musicInst:[
        {
            id: 1,
            name: 'Mini Keyboard',
            src: './img/Mini_keyboard3.jpg',
            price: 4496
        },
        {
            id: 2,
            name: 'Portable Keyboard',
            src: './img/Portable_keyboard2.jpg',
            price: 9446
        },
        {
            id: 3,
            name: 'Arranger Keyboard',
            src: './img/Arranger_keyboard2.jpg',
            price: 69300
        },
        {
            id: 4,
            name: 'Electric Guitar',
            src: './img/Electric_guitar.jpg',
            price: 22600
        },
        {
            id: 5,
            name: 'Smart Guitar',
            src: './img/Smart_guitar.jpg',
            price: 90000
        },
        {
            id: 6,
            name: 'Revolt Acoustic',
            src: './img/Revolt_acoustic.jpg',
            price: 6080
        },
        {
            id: 7,
            name: 'M_audio',
            src: './img/M_audio.jpg',
            price: 5604
        },
        {
            id: 8,
            name: 'Shruti Box',
            src: './img/ShrutiBox.jpg',
            price: 12600
        }
    ]
}