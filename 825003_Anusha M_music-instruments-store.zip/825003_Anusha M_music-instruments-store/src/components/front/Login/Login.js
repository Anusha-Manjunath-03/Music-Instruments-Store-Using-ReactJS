import React, { useRef } from 'react'
import './Login.css'

const Login = () => {

  const userName = useRef(null);
  const userPass = useRef(null);

  const handleLogin = ()=>
  {
    const uN = userName.current.value;
    const pW = userName.current.value;

    alert('You have logged in Successfully!!!');
  }

  return (
    <div>
        <h2 className='text-uppercase login_text'>login page</h2>
        <form className='forms'>
            <input type='text' placeholder='Enter Name' className='form-control form_input'  ref={userName}></input>
            <br></br>
            <br></br>
            <input type='password' placeholder='Password' className='form-control form_input' ref={userPass}></input>
            <br></br>
            <br></br>
            <button className='btn btn-secondary form-btn' onClick={handleLogin}>Login</button>
        </form>
        </div>
  )
}

export default Login