import React from 'react'
import { Link } from 'react-router-dom'
import './Header.css'

const Header = () => {
  return (
    <>
      <div className='div_h1'>
        <h1 className='shadow p-3 mb-5 bg-body-tertiary rounded'>
          <em>MUSIC STORES</em>
        </h1>
      </div>

      <div className='logo_div'>
        <div><Link to='/'><img src='./img/logo.jpg' alt='logo' /></Link> </div>
        <div></div>
      </div>

      <a href='https://idioteq.com/7-important-things-you-should-know-when-purchasing-a-musical-instrument/#:~:text=1%201.%20Understand%20Your%20Needs%20Every%20musician%E2%80%99s%20needs,Noise%20...%207%207.%20Consult%20an%20Expert%20'><p className='guide'>Ultimate Guide Before You Purchase</p></a>

      <div className='div2'>
        <div className='link_div'>
          <Link to='./'><i className="bi bi-house-fill div2_link"></i></Link>

          <Link to='./cart'><i className="bi bi-cart-check-fill div2_link"></i></Link>

          <Link to='./login'><i class="bi bi-box-arrow-in-right div2_link"></i></Link>
        </div>

      </div>
    </>
  )
}

export default Header