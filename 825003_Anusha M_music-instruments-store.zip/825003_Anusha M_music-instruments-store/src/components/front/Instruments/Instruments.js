import React from 'react'
import './Instruments.css'


const Instruments = ({ musicInst, handleAddInst }) => {
  return (
    <div className='instruments'>
      <h2 className="text-uppercase h2_style" style={{ textAlign: 'center' }}>Music Instruments</h2>
      <div className='insts'>
        {
          musicInst.map(
            (inst) => (
              <div className='card'>
                <div>
                  <img className='inst_image' src={inst.src} alt='Music instrument' />
                </div>

                <div className='inst_name'>
                  <h3>{inst.name}</h3>
                </div>

                <div className='inst_price'>
                  <h4>Rs. {inst.price}</h4>
                </div>

                <div>
                  <button className="btn btn-primary" onClick={() => handleAddInst(inst)}>Add To Cart</button>
                </div>
              </div>

            )
          )}

      </div>
    </div>
  )
}

export default Instruments