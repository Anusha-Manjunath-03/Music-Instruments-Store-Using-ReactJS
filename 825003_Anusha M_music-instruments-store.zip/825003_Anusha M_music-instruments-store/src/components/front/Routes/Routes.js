import React from 'react'
import { Routes,Route } from 'react-router-dom'
import Instruments from '../Instruments/Instruments'
import Cart from '../Cart/Cart'
import Login from '../Login/Login'

const MyRoutes = ({musicInst,handleAddInst,handleClearCart,handleRemoveInst,cartItems}) => {
  return (
    <div>
      <Routes>
        <Route path='/' element={<Instruments musicInst = {musicInst} handleAddInst = {handleAddInst}/>}></Route>

        <Route path='/login' element={<Login />}></Route>

        <Route path='/cart' element={<Cart 
        cartItems={cartItems}
        handleAddInst={handleAddInst}
        handleRemoveInst={handleRemoveInst}
        handleClearCart={handleClearCart}/>}></Route>
      </Routes>
    </div>
  )
}

export default MyRoutes