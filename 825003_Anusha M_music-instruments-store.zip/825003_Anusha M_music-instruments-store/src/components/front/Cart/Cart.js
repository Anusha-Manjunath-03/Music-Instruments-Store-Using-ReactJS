import React, { useState } from 'react'
import './Cart.css'

const Cart = ({cartItems, handleAddInst, handleRemoveInst, handleClearCart}) => {
  const totalPrice = cartItems.reduce(
    (price,inst)=> 
    price + inst.q * inst.price,0 
  )

  return (
    <div>
      <h1 className='text-uppercase title'>Welcome to Music Cart</h1>
      <div>
        {cartItems.length >= 1 && (<button onClick={handleClearCart} className='btn btn-secondary clear_btn'>Clear Cart</button>)}
      </div>
    <div className='cart'>
      
      {
        cartItems.length === 0 && (
          <h3 className='h3_cart'>
            Compose Your Tunes by adding your fav instrument from our store...
          </h3>
        )
      }
      <div className='card'>
        {
          cartItems.map(
            (inst) =>
            (
              <div className='card_inst'>
              <div key={inst.id}>
                <img src={inst.src} alt={inst.name} className='cart_image'></img>

                <div className='inst_name'>
                  <h3>{inst.name}</h3>
                </div>

                <div className='inst_price'>
                  <h5>{inst.price}</h5>
                  </div>
                  

                <div className='quan_div'>
                  <button onClick={()=>handleAddInst(inst)}><i className="bi bi-plus-circle icons btn_div inc_dec_btn"></i></button>
                  <h5 className='btn_div quantity'>{inst.q}</h5>
                  <button onClick={()=>handleRemoveInst(inst)}><i className="bi bi-dash-circle icons btn_div inc_dec_btn"></i></button>
                </div>

                <hr></hr>
                </div>
                
                </div>
            )
          )
        }
      </div>
      
    </div>
    <div className='cart_price'>
        <em>Total Price: Rs. {totalPrice}</em>
      </div>
    </div>
  )
}

export default Cart