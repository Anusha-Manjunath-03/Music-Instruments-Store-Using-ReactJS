import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <div className='shadow p-3 mb-5 bg-body-tertiary rounded footer'>
        <h3>Connect With Us</h3>
      <a href='https://www.instagram.com'><i className="bi bi-instagram icon"></i></a>
      <a href='https://www.threads.com'><i className="bi bi-threads icon"></i></a>
      <a href='https://www.facebook.com'><i class="bi bi-facebook icon"></i></a>
      <div className='location'>
        <h4>Find our Stores</h4>

        <div className='store_location'>
        <h5>Location 1:</h5>
        <p>Jayanagar</p>
        <p>No.3, Ground Floor, Garuda Mall, Magrath Road</p>
        <p>Bengaluru - 560011</p>
        </div>

        <div className='store_location'>
        <h5>Location 2:</h5>
        <p>JP Nagar</p>
        <p>No.21, Seventh Floor, Forum Mall</p>
        <p>Bengaluru - 562135</p>
        </div>

        <div className='store_location'>
        <h5>Location 3:</h5>
        <p>EC City</p>
        <p>No.38, Second Floor, K Mall, V Road</p>
        <p>Bengaluru - 566711</p>
        </div>

      </div>
    </div>
  )
}

export default Footer